package work;
import java.util.*;
public class Hashmap 
{
public static void main(String a[])
	{
	Map hm = new HashMap();
	hm.put(101,"ABC");
	hm.put(102,"XYZ");
	hm.put(103,"PQR");
	hm.put(104,"LMN");
//	System.out.println(hm);
	Set s=hm.entrySet();
	Iterator i=s.iterator();
	while(i.hasNext())
		{
			Map.Entry m=(Map.Entry)i.next();
			System.out.println(m.getKey());
		}
	}
}