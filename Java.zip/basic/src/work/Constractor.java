package work;

class Constractor 
{
	int a; char b;
	Constractor()
	{
		a=10; b='c';
	}
	void show()
	{
		System.out.println(a+" "+b);
	}
	public static void main(String[] args) 
	{
		Constractor con=new Constractor();
		con.show();
	}
}
