package work;

public class Forloop1 {
	
		public static void main(String [] args)
		{
			int num;
			for(num=1; num<=10; num++)
			{
				System.out.println(num + " ");
			}
		}
}


