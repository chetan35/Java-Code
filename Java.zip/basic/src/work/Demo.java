	// class & object

package work;

public class Demo 		// Class
{
	int a=10; int b=30;
	void main()
	{
		System.out.println(a+" "+b);
	}
	public static void main(String[] args) 
	{
		Demo sc = new Demo();              //Object
		sc.main();
	}
}

