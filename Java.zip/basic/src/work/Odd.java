package work;
import java.util.Scanner;
public class Odd 
{
	public static void main(String[] args) 
	{
		int a;
		System.out.println("Enter Your Number");
		Scanner sc = new Scanner(System.in);
		a=sc.nextInt();
		if(a % 2 == 0)
		{
			System.out.println("Number Is Even");
		}
		else
		{
			System.out.println("Number Is Odd");
		}
	}

	
	
}


