package work;
public class FirstThread implements Runnable				
{
				public void run()
						{
							for (int i=0;i<=10;i++)
							{
								System.out.println(i);
							}
						}
public static void main(String[] args) 
		{
		FirstThread F = new FirstThread();
		Thread T=new Thread(F);
		T.start();
		System.out.println("Hello");
		System.out.println("MICRO");
		System.out.println("PUNE");
		System.out.println("Chetan");
		System.out.println("computer ");
		System.out.println("hande");
		}	
}
