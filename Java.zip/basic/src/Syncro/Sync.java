package Syncro;
class A1
{
	int total_seat=20;
	synchronized void book_seat(int seats) 
	{
		if (total_seat >=seats) 
		{
			System.out.println("Ticket is booking Successfully");
			 total_seat = total_seat - seats;
			System.out.println("reamining seats are " + total_seat);
		}
		
		else 
		{
			System.out.println("Booking is Unsuccessful");
			System.out.println("reaming seats are  "+total_seat);
		}
	}	
}

public class Sync extends Thread 
{
	   static A1 a;
	   
	  int seats;
	  public void run() 
	  {
		  a.book_seat(seats);
	  }
	
	public static void main(String[] args) 
	{
		a=new A1();
		Sync s= new Sync();
		s.seats=13;
	}
}