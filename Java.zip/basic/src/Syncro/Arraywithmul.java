package Syncro;

public class Arraywithmul {

	public static void main(String[] args) {

		int a[] = new int[4];
		
			a[0]=4;
			a[1]=3;
			a[2]=1;
			a[3]=2;
			for(int b:a)
			{
		System.out.println(b);
			}
	}
}
