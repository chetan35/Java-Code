package Syncro;
import java.util.*;
class Treeset
{
		  public static void main(String[] args) 
		  {
			  TreeSet<Integer> a = new TreeSet<>();
			  a.add(120);
			  a.add(50);
			  a.add(12);
			  a.add(20);
			  a.add(100);
			  a.add(130);
			  a.add (200);
			 System.out.println(a);  
			 Iterator<Integer> iterator = a.descendingIterator();
			    while (iterator.hasNext()) 
			    {
			      System.out.println(iterator.next());
			    }
		  }
}
