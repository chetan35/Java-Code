				//parameterized constractor//


public class Chetan123 
{
	int x,y,z;
	public Chetan123(int a,int b,int c)
	{
		int x=a,y=b,z=c;
		System.out.println(+x+" "+y+" "+z);
	}	
	public static void main(String[] args) 
	{
		Chetan123 s = new Chetan123(10,20,50);
	}
}
