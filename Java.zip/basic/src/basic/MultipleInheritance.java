package basic;
import java.util.*;
class MultipleInheritance1 
{
	int a,b;
		void add()
		{
		Scanner q = new Scanner(System.in);
		System.out.println("Enter Your Value");
		a=q.nextInt();
		b=q.nextInt();
		System.out.println(a+b);
	}
}	
class B extends MultipleInheritance1
{
void Mul()
	{
	Scanner t = new Scanner(System.in);
	System.out.println("Enter Your Value");
	a=t.nextInt();
	b=t.nextInt();
	System.out.println(a*b);
	}
}
class C extends B
{
	void Div()
	{
	Scanner t = new Scanner(System.in);
	System.out.println("Enter Your Value");
	a=t.nextInt();
	b=t.nextInt();
	System.out.println(a/b);
	}
}
class D extends C
{
	void Modul()
	{
	Scanner t = new Scanner(System.in);
	System.out.println("Enter Your Value");
	a=t.nextInt();
	b=t.nextInt();
	System.out.println(a%b);
	}
}
public class MultipleInheritance
{
	public static void main(String[] args) 
	{
		D e=new D();
		e.add();
		e.Mul();
		e.Div();
		e.Modul();
	}
}

