package basic;


enum Week {
	
	mon,tue,wed,thr,fri,sat,sun
}
public class Enum {

	public static void main(String[] args) {
		Week w=Week.mon;
		System.out.println(w);

		
	}

}
