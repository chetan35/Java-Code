package basic;

public class Cylinder {

public static void main(String args[]) 
{
	int a = 10;
	System.out.println(a++);
	System.out.println(+a);
	System.out.println(a--);
	System.out.println(-a);
	System.out.println(a+=2);
	System.out.println(a-=2);
	System.out.println(a*=2);
	System.out.println(a/=2);
	System.out.println(a%=2);
}
}
