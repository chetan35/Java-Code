import java.util.HashSet;

public class HashSetExample 
{
  public static void main(String[] args) 
  {
    HashSet<String> set = new HashSet<>();
    set.add("apple");
    set.add("banana");
    set.add("cherry");
    set.size();
    System.out.println(set);
    set.remove("banana");
    {
      System.out.println(set);
    }
  }
}
