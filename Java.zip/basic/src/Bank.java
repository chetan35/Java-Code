class Bank
{
	public void main()
	{
			for (int i=0;i<=10;i++)
			{
				System.out.println(i);
			}
	}	
public static void main(String arg[])
{
	Thread T=new Thread();
	T.start();
	{
	System.out.println("Hello");
	}
}
}







