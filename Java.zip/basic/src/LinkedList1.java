			//sorting a data for asending order by using linked list//

import java.util.LinkedList;

public class LinkedList1
{
    public static void main(String[] args) 
    {
        LinkedList<Integer> list = new LinkedList<>();
        list.add(5);
        list.add(3);
        list.add(7);
        list.add(1);
        list.add(4);
        list.sort(null);
        System.out.println(list);
    }
}



