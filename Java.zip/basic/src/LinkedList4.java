			//linkedlist for add/remove // 

import java.util.*;
public class LinkedList4 
{
	  public static void main(String[] args) 
	  {
	    LinkedList<Integer> list = new LinkedList<>();
	    list.add(3);
	    list.add(2);
	    list.add(5);
	    list.add(1);
	    list.add(4);
	    System.out.println(list);
	    list.add(1,10);
	    System.out.println(list);
	    list.remove(3);
	    System.out.println(list);
	    }

	
}
