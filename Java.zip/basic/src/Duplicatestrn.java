import java.util.*;
public class Duplicatestrn 
{
public static void main(String[] args) 
	{
	List<String> s = new ArrayList<>();
	s.add("Chetan");
	s.add("Rahul");
	s.add("Chetan");
	s.add("Shyam");
	s.add("Vinay");
	s.add("Jayesh");
	
	Set<String> a = new LinkedHashSet<>(s);
	System.out.println(a);
	}
}
