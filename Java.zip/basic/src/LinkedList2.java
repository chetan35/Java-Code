				// LinkedList useing For loop//
import java.util.*;

public class LinkedList2 
{
public static void main(String a[]) 
{
	ArrayList a2 = new ArrayList();
	a2.add("rahul");
	a2.add("Ram");
	
	LinkedList <String> a1 = new LinkedList<String>(a2);
	a1.add("Chetan");
	a1.add("c");
	a1.add("123");
	a1.add("@");
	a1.add("50.4");
	
	for(String str:a1)
	{
		System.out.println(str);
	}
}
}
