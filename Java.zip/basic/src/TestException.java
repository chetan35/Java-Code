class TestException 
{
public static void main(String[] args) 
	{
	System.out.println("No Error Found");
	try 
	{
	int a=10,b=0,c;
	c=a/b;
	}
catch(ArithmeticException a)
{
	System.out.println("Can't Devide By Zero");
}
System.out.println("Main Method Is Ended");
}
}

