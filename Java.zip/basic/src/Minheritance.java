					//Multiple Inheritance//
import java.util.Scanner;
class Minheritance1 
{
	int a,b,c;
	void add()
	{
		System.out.println("Enter Friest value of Addition");
		Scanner x=new Scanner(System.in);
		a=x.nextInt();
		System.out.println("Enter second value of Addition");
		Scanner y=new Scanner(System.in);
		b=y.nextInt();
		c=a+b;
	System.out.println("Addition of two Numbers := "+c);
	}
}
class N extends Minheritance1
{
	 int q,w,e;
 void mul()
	{
	System.out.println("Enter Friest value of Multiplication");
	Scanner x=new Scanner(System.in);
	q=x.nextInt();
	System.out.println("Enter Second value of Multiplication");
	Scanner y=new Scanner(System.in);
	w=y.nextInt();
	e=q*w;
	System.out.println("Multipliation of Two Number Is:="+e);		
	}
}
class C extends N
{
	int r,t,u;
	void div()
	{		
		Scanner z=new Scanner(System.in);
		System.out.println("Enter Friest value of Division");
		r=z.nextInt();
		Scanner y=new Scanner(System.in);
		System.out.println("Enter Second value of Division");
		t=y.nextInt();
		u=r/t;
		System.out.println("Division Of Two Number Is:="+u);
	}
}
class D extends N
{
	int i,o,p;
	 void Sub()
	{
		System.out.println("Enter the Friest value of Substraction");
		Scanner e=new Scanner(System.in);
		i=e.nextInt();
		System.out.println("Enter the Second number of Substracrion");
		Scanner f=new Scanner(System.in);
		o=f.nextInt();
		p=i-o;
		System.out.println("Substraction of Two Number Is:="+p);
	}
}
class E extends D
{
	int p,s,d;
	void mod()
	{
		System.out.println("Enter the friest value of Modulas");
		Scanner g=new Scanner(System.in);
		p=g.nextInt();
		System.out.println("Enter the Scond Number Of Modulas");
		Scanner n=new Scanner(System.in);
		s=n.nextInt();
		d=p%s;
		System.out.println("Modulas Of Two Number Is:="+d);
	}
}
class Minheritance
{																			
public static void main (String args[])
	{
	E l = new E();
	l.add(); 
	l.mul(); 
	//l.div();
	l.mod(); 
	l.Sub();
	}
}
