public class Pconst 
{
	int a; float b; int c;
	private Pconst()
	{
		a=10; b=1; c=80;
		System.out.println(a+" "+b+" "+c);
	}
	static void show()
	{
		int a=20; int b=60;
		int c=a*b;
		System.out.println(+c);
	}
	public static void main(String[] args) 
	{
		Pconst cos=new Pconst();
		cos.show();
	}
}
