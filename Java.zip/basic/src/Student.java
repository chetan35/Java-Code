			// simple inheritance //
public class Student    //super class
{
	int roll,marks;
	String name;
	void input()
	{
	System.out.println("roll name & marks");
	}
}
class Chetan extends Student     //sub class
{
	void disp()
	{
	roll=10; marks=80; name="rahul";
	System.out.println(roll+" "+marks+" "+name);
	}
	public static void main(String a[])
	{
		Chetan ch= new Chetan();
		ch.input();
		ch.disp();
		
	}
	
}
	