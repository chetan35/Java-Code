
public class Spaceremove 
{
public static void main(String[] args) 
	{
		String s = "c h   e t   a n";
		String a=s.replaceAll(" ","");
	
		System.out.println(a);
	}
}