
public class Strspc 
{
	public static void main(String[] args) 
	{
		String s = "mic$rolearn&Cheta@n";
		s=s.replaceAll("[^0-1A-Za-z]"," ");
		System.out.println(s);
	}
}
