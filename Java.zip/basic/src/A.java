
public class A extends Thread
{
	public void run()
	{
		for(int i=1;i<=5;i++)
		{
	System.out.println("Chetan");
		}
	}
}
class Cartoon
{
public static void main(String a[])
{
	Thread t=new Thread();
	t.start();
	for(int i=1;i<=5;i++)
	{
System.out.println("Chetan");
	}


}
}