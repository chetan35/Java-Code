								//Create a file//


import java.io.*;
public class F 
{
public static void main(String[] args) 
	{
		File F = new File("C:\\Users\\RM-IT\\Desktop\\java program\\chetan.txt");
		try
		{
				if(F.createNewFile())
				{
					System.out.println("File Is Successfully Created");
				}
				else
				{
					System.out.println("File Is Already Exist");
				}
		}
		catch(IOException r)
		{
			System.out.println("Exception Handled");
		}
	}
	
	
}
