class B {

	int TotalAmount = 5000;

	 void Amount(int Balance) {
		if (TotalAmount >= Balance) {
			System.out.println("Enter Withdraw Amount");
			TotalAmount = TotalAmount - Balance;
			System.out.println("Reamining Amount are " + TotalAmount);
		} else {
			System.out.println("Transaction is Unsuccessful");
			System.out.println("Reaming Amount are  " + TotalAmount);
		}
		System.out.println("Thank you....!!");
	}
}

class H extends Thread {
	B b1 = new B();
	int Balance1 = 2000;
	

	public void run()

	{
		b1.Amount(Balance1);
	}
}

class A1 {

	public static void main(String[] args) {
		H T1 = new H();
		T1.start();
		
	
		
		

	}

}