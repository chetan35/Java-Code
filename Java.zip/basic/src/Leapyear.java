
public class Leapyear 
{

public static void main(String[] args) 
		{
			int Y = 2020;
			if((Y%400==0)||(Y%4==0)&&(Y%100!=0))
			{
				System.out.println("Year"+" "+Y+" "+"Is Leap year");
			}
			else
			{
				System.out.println("Year"+" "+Y+" "+"Is Not Leap year");
			}
		}	
}
