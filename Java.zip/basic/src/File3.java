import java.io.*;
public class File3 
{
	public static void main(String[] args) throws IOException
	{
		FileReader r = new FileReader("C:\\Users\\RM-IT\\Desktop\\chetan.txt");
		try 
		{
			try 
			{
			int i;
			while((i=r.read())!=-1)
			{
			System.out.print((char)i);
			}
			}
			finally 
			{
				r.close();
			}
		}
		catch(IOException h)
		{
			
		}
		System.out.println("File Write Successfully");	
		}
}		
