				//file information//


import java.io.*;
public class F1 
{
public static void main(String[] args) 
{
	File F = new File("C:\\Users\\RM-IT\\Desktop\\java program\\chetan.txt");
	
	if(F.exists())
		{
			System.out.println("File Name - " +F.getName());
			System.out.println("File Location - " +F.getAbsolutePath());
			System.out.println("File Writeble - " +F.canWrite());
			System.out.println("File Writeble - " +F.canRead());
			System.out.println("File Size - " +F.length());	
		}
	else
	{
	System.out.println("File Not Found");	
	}
}
}
