						// StringBuffer capacity Method//


public class String1 
{
public static void main(String[] args) 
	{
	StringBuffer sb = new StringBuffer();
	sb.append("Chetan");  
	System.out.println(sb.capacity());
	sb.append("Hande");  
	System.out.println(sb.capacity());
	}
}
