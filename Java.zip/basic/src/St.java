						// String Buffer//


public class St 
{
	public static void main(String args [])
	{
		StringBuffer ch = new StringBuffer("Chetan ");
		ch.append("Hande");
		System.out.println(ch);
	} 
}

