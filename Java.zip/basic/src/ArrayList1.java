import java.util.*;
public class ArrayList1 
{
	public static void main(String a[]) 
{
	ArrayList a1 = new ArrayList();
	a1.add("Chetan");
	a1.add('c');
	a1.add("123");
	a1.add("@");
	a1.add("50.4");
	a1.add("Null");
	
	
	Iterator M = a1.listIterator();

	while(M.hasNext())  
	{
		System.out.println(M.next());
	}
}
}
