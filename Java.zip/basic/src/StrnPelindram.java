			//String data to convert in Char data

public class StrnPelindram 
{
	public static void main(String[] args) 
	{
		String a= "chetan";
		String s= "";
		for (int i=a.length()-1;i>=0;i--)
		{
			s=s+a.charAt(i);
			}
	
		System.out.println(s);
		if(a.equals(s))
		{
			System.out.println("String Is pelindram");
		}
		else
		{
			System.out.println("Sring Is Not Palindram");
		}
	}
}
	
	
	
