public class Logic {

	public static void main (String args[])
	{
		String Logic = "Admin123";
		String password = "123";
				
				if(Logic.equals("Admin123") || password.equals("123"))
					System.out.println("Your password is Match");
					else
					{
						System.out.println("Your Password Is Not Match");
					}
				
	}
	
}
