
public class Vec {

}
