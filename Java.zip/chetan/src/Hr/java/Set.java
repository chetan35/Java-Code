package Hr.java;
import java.util.*;
public class Set 
{
	public static void main(String[] args) 
	{
		HashSet a1 = new HashSet();
		a1.add("Chetan");
		a1.add('c');
		a1.add("123");
		a1.add("@");
		a1.add("50.4");
		a1.add("Null");
		
//		System.out.println(a1);
		Iterator r = a1.iterator();
		while (r.hasNext())
		{
			System.out.println(r.next());
		}
	}
}
