package Hr.java;

public class A {

}
