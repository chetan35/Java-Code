package Hr.java;

public class Data1 {
public static void main(String args [])
{
	int chetan = 10;
	long b = chetan;
	System.out.println(b);
	
	float c = 10.0f;
	double d = c;
	System.out.println(d);
	
	char e = 'a';
	int f = e;
	System.out.println(f);
	
	byte g = 10;
	double h = g;
	System.out.println(h);

	short i = 10;
	long j = i;
	System.out.println(j);

	long k = 102030;
	int l = (int)k;
	System.out.println(l);
}
}
