package Hr.java;

class Program{
public static void main(String... args)
{
String tech = "Java";
char[] a = tech.toCharArray();
String rev = " ";
for(int i=a.length-2;i>=0;i--)
{
rev += a[i];
}
System.out.print(rev);
}
}