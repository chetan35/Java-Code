package Hr.java;
import java.util.Scanner;
public class Arth 
	{
	public static void main(String args[])
	{
		Scanner scr = new Scanner(System.in);
		System.out.println("enter First no: ");
		int a = scr.nextInt();
		System.out.println("enter second no: ");
		int b = scr.nextInt();
		int c = a + b;
		System.out.println(c);
	}
}