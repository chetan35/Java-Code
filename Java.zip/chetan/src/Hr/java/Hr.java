package Hr.java;

public class Hr 
{

	public void Hrinfo()
	{
		System.out.println("Hr.Name - ");
		System.out.println("Hr.Id - ");
		System.out.println("Hr.Address - ");
	}
		
	public static void main(String[] args) 
	{
		Hr obj = new Hr();
		obj.Hrinfo();
		

	}
}