package chetan;

public class switch2 {
public static void main (String[] args) 
{
	int Day=6;
	switch (Day)
	{
	case 1 : System.out.println("Monday");
	break;
	case 2 : System.out.println("Tusday");
	break;
	case 3 : System.out.println("Thusday");
	break;
	case 4 : System.out.println("Friday");
	break;
	case 5 : System.out.println("Saturday");
	break;
	case 6 : System.out.println("Sunday");
	break;
	default : System.out.println("Invalid Number");
	}
}
}
