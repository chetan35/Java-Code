package chetan;

public class ifelseladder 
{
	public static void main (String[] args)
	{
		int Marks = 80;
		if(Marks>100 || Marks<0)
			System.out.println("Invalid Marks");
			else {
				if(Marks>=85)
					System.out.println("A");
				else
					if(Marks>=75)
							System.out.println("B");
					else
						if(Marks>=65)
								System.out.println("C");
						else
							if(Marks>=35)
							System.out.println("D");
							else
								System.out.println("Fail");
						}
					}
				}
			
	

