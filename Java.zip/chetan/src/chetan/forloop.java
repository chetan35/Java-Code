package chetan;

public class forloop 
{
public static void main(String [] args)
	{
	int num=0;
	do {
		System.out.println(+num);
		num++;
		}
	while(num<=10);
		{
		System.out.println(num + " ");
		
		}
	}
}
