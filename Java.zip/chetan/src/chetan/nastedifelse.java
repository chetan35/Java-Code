package chetan;

public class nastedifelse 
{
	public static void main(String[] args) 
	{
		int A=15,B=15,C=16;
					{
						if(A==B && B==C)
							System.out.println("All Number Are Same");
						else {

							if(A==B)
								System.out.println("A and B Are Same");
								if(A==C)
									System.out.println("A And C Are Same");
								if(B==C)
								System.out.println("B And C Are Same");}
								
								if(A>B)
									{
									if(A>C)
										System.out.println(" A Is A Max That Is " +A);
									else
										System.out.println(" C Is A Max That Is " +C);
									}
								else
									{
									if(B>C)
										System.out.println(" B Is A Max That Is " +B);
									else
										System.out.println(" C Is A Max That Is " +C);
									}
					}
	}
}
