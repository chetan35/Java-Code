package chetan;
public class demo1 
{
public static void main(String[] args)
	{
	int A=20;
	int B=20;
	if(A==B)
		System.out.println("Both are same");
	else
		{
		System.out.println("Both are Diffrent");
		if(A>B)
			System.out.println("A is max and B is min");
		else
			System.out.println("B is max and A is min");
		}
	}
}