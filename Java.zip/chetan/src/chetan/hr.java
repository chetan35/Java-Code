package chetan;

public class hr 
{

	public void hrinfo()
	{
		System.out.println("hr name");
		System.out.println("hr id");
		System.out.println("hr address");
	}
		
	public static void main(String[] args) 
	{
		hr obj = new hr();
		obj.hrinfo();
		

	}

}
