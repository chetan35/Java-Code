// DataBase creation //
package JDBC1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Newdatabase_creation 
{
public static void main(String a[]) 
{
	try 
	{
Class.forName("com.mysql.cj.jdbc.Driver");
System.out.println("Done");
Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306","root","123456");
Statement st = con.createStatement();
System.out.println("Ok");
st.execute("Create database jdbc_3");
System.out.println("Database created successfully !!");
   }
catch(Exception d)
	{
	
	}
	}
}
