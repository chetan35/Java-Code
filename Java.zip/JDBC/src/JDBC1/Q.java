package JDBC1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;
public class Q 
{
		public static void main(String args[]) 
		{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Loade Successfully");
			Connection Con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/chetan","root","123456");
			Statement st = Con.createStatement();
			//st.executeUpdate("create database Chetan"); for create new database
			//st.executeUpdate("create table chetean(ID int,Name varchar(20),Address varchar(20),Mobile_No int,City varchar(10),Salary int)");

			Scanner sc = new Scanner(System.in);
			System.out.println("Enter ID");
			int ID =sc.nextInt();
			
			Scanner a = new Scanner(System.in);
			System.out.println("Enter Name");
			String Name =a.nextLine();
			
			Scanner b = new Scanner(System.in);
			System.out.println("Enter Address");
			String Address =b.nextLine();
			
			Scanner c = new Scanner(System.in);
			System.out.println("Enter Mobile_No");
			int Mobile_No =c.nextInt();
			
			Scanner d = new Scanner(System.in);
			System.out.println("Enter City");
			String City =d.nextLine();

			Scanner e = new Scanner(System.in);
			System.out.println("Enter salary");
			int Salary =e.nextInt();
			
			st.executeUpdate("insert into chetean values('"+ID+"','"+Name+"','"+Address+"','"+Mobile_No+"','"+City+"','"+Salary+"')");
		
		}
		catch(Exception e)
		{
			
		}
		System.out.println("Cannection established");
		}
}
