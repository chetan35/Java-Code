package JDBC1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Jdbc 
{
	public static void main(String[] args) throws Exception 
	{
		try 
		{
	Class.forName("com.mysql.jdbc.Driver");
	System.out.println("Zalana Bho Driver Load");
	Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/employee","root","123456");
	System.out.println("Connection Successfully");
	Statement st = con.createStatement();

	//st.execute("create database JDBC");
	//System.out.println("Database Is Created");
	//st.execute("create table emp2(ID int,Name varchar(10),Address varchar(10),ContactNo int,City varchar(10))");
	//st.executeUpdate("insert into emp2 values (01,'Chetan','Pune',9158458,'Nashik');");
	st.executeUpdate("insert into emp2 values (01,'Pandit','Pune',9158458,65200,);");
	st.executeUpdate("insert into chetean values (01,'Kamlesh','Pune',9158458,'Nashik',45000);");
	//System.out.println("Data Updated");
	//st.executeUpdate("insert into emp2 values (02,'Rahul','Nager',456123,'Akole');");
	//System.out.println("Data Updated YaaaaHoooo");
	//st.executeUpdate("insert into emp2 values (03,'Ram','Dhule',785965,'Dehu')");
	//System.out.println("Value Updated");
	//st.executeUpdate("Alter table emp2 add salary int after city ");
	//System.out.println("Done");
	//st.executeUpdate("Alter table emp2 drop city");
	//System.out.println("Done");
	//st.executeUpdate("Alter table emp2 add salary int after city ");
	System.out.println("Done");
	/*ResultSet rs = st.executeQuery("select * form emp2");
	while(rs.next()) 
	{
		System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3));
		}*/
	}
		catch(Exception e) 
		{
			
		}
}
}