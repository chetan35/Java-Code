package JDBC1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;

public class WIthSc {
	public static void main(String[] args)
	{
	try
	{
	while(true)
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver Is Loaded");
		Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/employee","root","123456");
		System.out.println("Connection Successfully");
		Statement st = con.createStatement();
		System.out.println("Connection Successfully");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter ID");
		int ID =sc.nextInt();
	
		Scanner a = new Scanner(System.in);
		System.out.println("Enter Name");
		String Name =a.nextLine();
	
		Scanner c = new Scanner(System.in);
		System.out.println("Enter Address");
		String Address =c.nextLine();
	
		Scanner d = new Scanner(System.in);
		System.out.println("Enter Contact No");
		int Contact =d.nextInt();
		
		Scanner e = new Scanner(System.in);
		System.out.println("Enter Salary");
		int Salary =e.nextInt();
		
		st.executeUpdate("insert into emp2 values('"+ID+"','"+Name+"','"+Address+"','"+Contact+"','"+Salary+"')");
		
		System.out.println("Finish");
	
		Scanner ac=new Scanner(System.in);
		System.out.println("Do you want to continue [Yes/No]");
		String option=ac.nextLine();
	
		if(option.equalsIgnoreCase("No"))
		{
		System.out.println("Thank you for using my Application");
		break;
	}
	
	}
	}
	catch(Exception e)
	{
	
	}
	}
}
