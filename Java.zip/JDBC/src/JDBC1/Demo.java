package JDBC1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo 
{
	public static void main(String[] args)
	{
	try
	{
	Class.forName("com.mysql.cj.jdbc.Driver");
	System.out.println("Driver Is Loaded");
	Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/employee","root","123456");
	System.out.println("Connection Successfully");
	Statement st = con.createStatement();
	ResultSet rs = st.executeQuery("select * form emp2");
	while(rs.next())
	{
		System.out.println(rs.getInt(1));
	}
	}
	catch(Exception ex)
	{
	
	}
  }
}

