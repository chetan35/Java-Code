// Data Enter in specific coloum //

package JDBC1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class A 
{
		public static void main(String[] args)
		{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver Is Loaded");
			Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/employee","root","123456");
			System.out.println("Connection Successfully");
			Statement st = con.createStatement();
			Connection con1 = DriverManager.getConnection("jdbc:mysql://Localhost:3306/chetan","root","123456");
			System.out.println("Connection Successfully");
			Statement st1 = con.createStatement();
//			st.executeUpdate("UPDATE emp2 SET Salary=60000,Name='Chetan'WHERE Address='Pune';");
			//st.executeUpdate("insert into emp2 values (01,'Pandit','Pune',9158458,65200,);");
			//st.executeUpdate("insert into chetean values (02,'Kamlesh','Pune',9158458,'Nashik',45000);");
			System.out.println("Finish");
		}
		catch(Exception e)
		{
		
		}
	 }
}


