package JDBC1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class J {
		public static void main(String[] args) throws Exception 
		{
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Driver Is Loaded");
		Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/employee","root","123456");
		System.out.println("Connection Successfully");
		Statement st = con.createStatement();
		}
	}

